const assert=require('node:assert/strict');
const fs=require('node:fs');
const {Colony}=require('./model.js');
const rows=[];
for(const seed of [11,29,73,101,307]){
 const initial=new Colony(seed);for(let i=0;i<600;i++)initial.step();
 const arms={stationary:initial.clone(),stationaryRain:initial.clone(),moved:initial.clone(),movedRain:initial.clone()};
 arms.moved.relocateFood();arms.movedRain.relocateFood();
 assert.deepEqual(arms.moved,arms.movedRain);
 arms.stationaryRain.erase(48,30,200);arms.movedRain.erase(48,30,200);
 const samples=[];
 for(let i=1;i<=600;i++){
  for(const c of Object.values(arms))c.step();
  if(i%100===0)samples.push({tick:600+i,...Object.fromEntries(Object.entries(arms).map(([k,c])=>[k,c.delivered-initial.delivered]))});
 }
 for(const c of Object.values(arms))assert.equal(c.delivered+c.ants.filter(a=>a.loaded).length+c.food.reduce((s,f)=>s+f.amount,0),1200);
 const gains=Object.fromEntries(Object.entries(arms).map(([k,c])=>[k,c.delivered-initial.delivered]));
 rows.push({seed,baseline:initial.delivered,gains,stationaryRainEffect:gains.stationaryRain-gains.stationary,movedRainEffect:gains.movedRain-gains.moved,samples});
}
const effects=rows.map(r=>r.movedRainEffect);
const report={question:'Does removing stale scent help after both twins move remaining food at tick 600?',forkTick:600,endTick:1200,oldPositions:[[68,16],[78,46]],newPositions:[[42,8],[48,52]],limits:'Five preselected seeds, one relocation geometry, toy model. New piles are nearer home; compare rain within layout, not moved versus stationary yields. Random streams diverge after intervention. Not biological or population evidence.',summary:{movedRainEffects:effects,mean:effects.reduce((s,x)=>s+x,0)/effects.length,positive:effects.filter(x=>x>0).length},rows};
fs.writeFileSync('evidence/paired-relocation.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({summary:report.summary,rows:rows.map(({samples,...row})=>row)},null,2));
