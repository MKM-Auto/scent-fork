// Execute the unchanged four-arm protocol with held-out seeds and a separate output.
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
let source=fs.readFileSync('experiment-relocation.cjs','utf8');
assert(source.includes('[11,29,73,101,307]'));
source=source.replace('[11,29,73,101,307]','Array.from({length:30},(_,i)=>1000+i)')
 .replace('evidence/paired-relocation.json','evidence/heldout-relocation.json')
 .replace('Five preselected seeds','Thirty held-out seeds (1000–1029)');
vm.runInNewContext(source,{require,console:{log(){}}},{filename:'heldout-protocol.cjs'});
const path='evidence/heldout-relocation.json';
const report=JSON.parse(fs.readFileSync(path,'utf8'));
assert.equal(report.rows.length,30);
function distribution(values){const sorted=[...values].sort((a,b)=>a-b);return {positive:values.filter(x=>x>0).length,zero:values.filter(x=>x===0).length,negative:values.filter(x=>x<0).length,median:(sorted[14]+sorted[15])/2,min:sorted[0],max:sorted[29],mean:values.reduce((a,b)=>a+b,0)/30};}
report.summary={moved:distribution(report.rows.map(r=>r.movedRainEffect)),stationary:distribution(report.rows.map(r=>r.stationaryRainEffect))};
fs.writeFileSync(path,JSON.stringify(report,null,2));
console.log(JSON.stringify({summary:report.summary,effects:report.rows.map(r=>({seed:r.seed,moved:r.movedRainEffect,stationary:r.stationaryRainEffect}))},null,2));
