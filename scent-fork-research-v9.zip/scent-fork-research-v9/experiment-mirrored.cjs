'use strict';
// Geometry-control experiment: do not change the production model or prior evidence.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {Colony}=require('./model.js');
const prior=JSON.parse(fs.readFileSync('evidence/heldout-relocation.json','utf8'));
const positions=[[68,44],[78,14]];
const total=c=>c.delivered+c.ants.filter(a=>a.loaded).length+c.food.reduce((s,f)=>s+f.amount,0);
const distance2=(f,n)=>(f.x-n.x)**2+(f.y-n.y)**2;
function mirror(c){
 const before=c.clone();
 c.food.forEach((f,i)=>{
  const d=distance2(f,c.nest);
  [f.x,f.y]=positions[i];
  assert.equal(distance2(f,c.nest),d);
 });
 const restored=c.clone();restored.food=before.food;
 assert.deepEqual(restored,before,'Only food coordinates may change');
 assert.equal(total(c),1200);
}
function distribution(values){
 const s=[...values].sort((a,b)=>a-b);
 return {positive:values.filter(x=>x>0).length,zero:values.filter(x=>x===0).length,negative:values.filter(x=>x<0).length,median:(s[14]+s[15])/2,min:s[0],max:s[29],mean:values.reduce((a,b)=>a+b,0)/values.length};
}
assert.equal(prior.rows.length,30);
const rows=[];
for(let seed=1000;seed<1030;seed++){
 const initial=new Colony(seed);for(let t=0;t<600;t++)initial.step();
 const arms={stationary:initial.clone(),stationaryRain:initial.clone(),moved:initial.clone(),movedRain:initial.clone()};
 mirror(arms.moved);mirror(arms.movedRain);
 assert.deepEqual(arms.moved,arms.movedRain);
 arms.stationaryRain.erase(48,30,200);arms.movedRain.erase(48,30,200);
 const samples=[];
 for(let t=1;t<=600;t++){
  for(const c of Object.values(arms)){c.step();assert.equal(total(c),1200);}
  if(t%100===0)samples.push({tick:600+t,...Object.fromEntries(Object.entries(arms).map(([k,c])=>[k,c.delivered-initial.delivered]))});
 }
 const gains=Object.fromEntries(Object.entries(arms).map(([k,c])=>[k,c.delivered-initial.delivered]));
 const reference=prior.rows.find(r=>r.seed===seed);
 assert.equal(initial.delivered,reference.baseline);
 for(const name of ['stationary','stationaryRain']){
  assert.equal(gains[name],reference.gains[name]);
  samples.forEach((s,i)=>assert.equal(s[name],reference.samples[i][name]));
 }
 const movedRainEffect=gains.movedRain-gains.moved;
 rows.push({seed,baseline:initial.delivered,gains,movedRainEffect,stationaryRainEffect:gains.stationaryRain-gains.stationary,priorMovedRainEffect:reference.movedRainEffect,changeFromPrior:movedRainEffect-reference.movedRainEffect,samples});
}
const report={question:'Does rain still help when relocation preserves each food pile distance from the nest?',forkTick:600,endTick:1200,seeds:'1000–1029, all retained',oldPositions:[[68,16],[78,46]],newPositions:positions,nest:{x:18,y:30},checks:{equalSquaredNestDistances:true,onlyFoodCoordinatesChanged:true,conservationEveryPostInterventionTick:true,stationaryGainsAndTracesExactlyMatchPrior:true},limits:'Same previously tested seeds; this is a geometry control, not a fresh held-out seed replication. Reflection controls nest distance, not path overlap, boundary effects or discovery difficulty. Divergent random streams, toy rules and one horizon remain. No biological inference.',summary:{mirrored:distribution(rows.map(r=>r.movedRainEffect)),priorNearer:distribution(rows.map(r=>r.priorMovedRainEffect)),stationary:distribution(rows.map(r=>r.stationaryRainEffect)),changeFromPrior:distribution(rows.map(r=>r.changeFromPrior))},rows};
fs.writeFileSync('evidence/mirrored-relocation.json',JSON.stringify(report,null,2));
const signed=n=>n>0?'+'+n:String(n);
const lines=['# Equal-distance relocation experiment','','Run `node experiment-mirrored.cjs` from scent-fork. Same model, seeds 1000–1029, four arms, fork at 600, stop at 1200. Only this runner changes remaining food coordinates to (68,44)/(78,14). Production UI is unchanged.','','All paired effects are rain-minus-kept food deliveries. Every seed is reported; no selection.',''];
for(const r of rows)lines.push(`- ${r.seed}: mirrored ${signed(r.movedRainEffect)}; prior nearer ${signed(r.priorMovedRainEffect)}; stationary ${signed(r.stationaryRainEffect)}; mirrored-minus-prior ${signed(r.changeFromPrior)}`);
lines.push('','## Distributions','',...Object.entries(report.summary).map(([k,v])=>`- ${k}: positive/zero/negative ${v.positive}/${v.zero}/${v.negative}; median ${signed(v.median)}; range ${signed(v.min)} to ${signed(v.max)}; mean ${v.mean.toFixed(3)}.`),'','## Checks and limits','',JSON.stringify(report.checks), '',report.limits,'');
fs.writeFileSync('evidence/mirrored-relocation.md',lines.join('\n'));
console.log(JSON.stringify({summary:report.summary,checks:report.checks,effects:rows.map(({seed,movedRainEffect,changeFromPrior})=>({seed,movedRainEffect,changeFromPrior}))},null,2));
