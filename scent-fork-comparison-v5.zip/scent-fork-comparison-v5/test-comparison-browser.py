from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root = Path(__file__).parent
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe', headless=True)
    page = browser.new_page(viewport={'width':1280,'height':1100})
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto((root/'index.html').as_uri())
    assert page.locator('#nearer').count() == 1, 'missing same-seed nearer comparison preset'
    results={}
    for layout, filename, positions in [('nearer','heldout-relocation.json',[[42,8],[48,52]]),('mirrored','mirrored-relocation.json',[[68,44],[78,14]])]:
        page.locator('#'+layout).click()
        assert layout in page.locator('#scenario').inner_text().lower()
        assert '1000' in page.locator('#scenario').inner_text()
        assert page.evaluate('control.tick === 600 && experiment.tick === 600 && !running')
        assert page.evaluate('control.food.map(f=>[f.x,f.y])') == positions
        assert page.evaluate('JSON.stringify(control)===JSON.stringify(experiment)')
        assert page.evaluate('oldFood') == [{'x':68,'y':16},{'x':78,'y':46}]
        page.locator('#rain').click()
        page.locator('#observe').click()
        row=next(r for r in json.loads((root/'evidence'/filename).read_text())['rows'] if r['seed']==1000)
        for selector, key in [('#leftstats','moved'),('#rightstats','movedRain')]:
            text=page.locator(selector).inner_text()
            assert 'tick 1200' in text and f"+{row['gains'][key]} since tick 600" in text, text
        assert page.evaluate('[control,experiment].every(c=>c.delivered+c.food.reduce((s,f)=>s+f.amount,0)+c.ants.filter(a=>a.loaded).length===1200)')
        results[layout]={'kept':page.locator('#leftstats').inner_text(),'rain':page.locator('#rightstats').inner_text()}
        page.locator('#observe').click()
        assert page.evaluate('control.tick===1200 && !running'), 'repeat observation must not overshoot'
        page.screenshot(path=str(root/f'evidence/comparison-{layout}.png'),full_page=True)
        page.locator('#fork').click()
        assert page.evaluate('JSON.stringify(control)===JSON.stringify(experiment) && oldFood.length===2')
        assert '+0 since tick 1200' in page.locator('#rightstats').inner_text()
        page.locator('#reset').click()
        assert page.evaluate('baseline===null && oldFood.length===0 && control.tick===0')
        assert '73' in page.locator('#scenario').inner_text()
    page.locator('#relocate').click()
    assert '73' in page.locator('#scenario').inner_text()
    page.set_viewport_size({'width':390,'height':844})
    page.locator('#mirrored').click()
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.screenshot(path=str(root/'evidence/comparison-mobile.png'),full_page=True)
    assert not errors, errors
    results['errors']=errors
    (root/'evidence/comparison-browser.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results))
    browser.close()
