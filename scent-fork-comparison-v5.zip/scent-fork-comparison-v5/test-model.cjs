const assert = require('node:assert/strict');
const fs = require('node:fs');
assert.ok(fs.existsSync(__dirname+'/model.js'), 'colony model must exist');
const {Colony} = require('./model.js');
const a = new Colony(73);
for(let i=0;i<1800;i++) a.step();
assert.ok(a.delivered>0,'ants must find and deliver food');
assert.equal(a.delivered+a.ants.filter(x=>x.loaded).length+a.food.reduce((s,f)=>s+f.amount,0),1200,'food conserved');
const b=a.clone(); for(let i=0;i<60;i++){a.step();b.step();}
assert.deepEqual(a,b,'clones evolve identically');
console.log('PASS foraging, conservation, deterministic fork; delivered',a.delivered);
assert.equal(typeof b.erase,'function','localized memory erasure must exist');
const ants=JSON.stringify(b.ants), food=JSON.stringify(b.food);
const sum=c=>c.scent.reduce((s,v)=>s+v,0);
b.erase(48,30,200);
assert.equal(sum(b),0);assert.equal(JSON.stringify(b.ants),ants);assert.equal(JSON.stringify(b.food),food);
assert.ok(sum(a)>0,'control untouched');
for(let i=0;i<300;i++){a.step();b.step();}
assert.notDeepEqual(a.ants,b.ants,'intervention changes behavior');
const c=new Colony(1);c.scent.fill(1);c.erase(30,30,3);
assert.equal(c.scent[c.at(30,30)],0);assert.equal(c.scent[0],1);
console.log('PASS localized erasure, no ant/food changes, control isolation, behavioral divergence');
